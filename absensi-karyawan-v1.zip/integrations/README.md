# Integrasi lanjutan

## Google OAuth
Ganti `/auth/demo-login` dengan Google OAuth/OIDC verification. Setelah Google mengembalikan ID token yang valid, cari user berdasarkan email/google_id. Jangan menjadikan email dari client sebagai bukti identitas.

## Google Sheets
Spreadsheet sebaiknya menjadi laporan/sinkronisasi, bukan database utama. Struktur yang disiapkan:
- USERS
- EMPLOYEES
- ATTENDANCE
- HOLIDAYS
- SETTINGS

## Nextcloud
Foto absensi dapat diunggah ke folder:
`/Absensi/YYYY/MM/DD/<employee>-IN.jpg`
`/Absensi/YYYY/MM/DD/<employee>-OUT.jpg`

Gunakan WebDAV/Nextcloud API dengan kredensial service account/app password di backend, bukan di aplikasi HP.

## Notifikasi
Untuk notifikasi 08:30 dan 17:30, gunakan push notification service dari backend. Penjadwalan harus menggunakan timezone Asia/Jakarta dan hanya aktif pada hari kerja.

## Google Maps Timeline
V1 tidak mengambil Google Maps Timeline pribadi karyawan. Jika diperlukan tracking lokasi kerja, implementasikan fitur location tracking tersendiri dengan persetujuan dan kebijakan privasi.
