const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const CHECK_IN_TIME = process.env.CHECK_IN_TIME || '08:30';
const CHECK_OUT_TIME = process.env.CHECK_OUT_TIME || '17:30';

const roles = ['ADMIN', 'OPERATOR', 'USER'];
const users = [
  { id: uuid(), email: 'admin@demo.local', name: 'Admin Demo', role: 'ADMIN', active: true },
  { id: uuid(), email: 'operator@demo.local', name: 'Operator Demo', role: 'OPERATOR', active: true },
  { id: uuid(), email: 'user@demo.local', name: 'User Demo', role: 'USER', active: true }
];
const employees = users.map((u, i) => ({
  id: uuid(), userId: u.id, employeeNumber: `EMP-${String(i+1).padStart(3,'0')}`,
  position: u.role === 'ADMIN' ? 'Administrator' : u.role === 'OPERATOR' ? 'Operator' : 'Staff',
  department: 'General'
}));
const attendance = [];
const holidays = []; // Format: YYYY-MM-DD

function jakartaNow() {
  return new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
}
function dateKey(d = jakartaNow()) {
  return d.toISOString().slice(0, 10);
}
function minutes(hhmm) {
  const [h,m] = hhmm.split(':').map(Number); return h*60+m;
}
function statusForIn(d) {
  const mins = d.getHours()*60 + d.getMinutes();
  return mins <= minutes(CHECK_IN_TIME) ? 'ON_TIME' : 'LATE';
}
function auth(req,res,next) {
  const h=req.headers.authorization||'';
  if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Unauthorized'});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'Invalid token'}); }
}
function requireRole(...allowed) {
  return (req,res,next)=> allowed.includes(req.user.role) ? next() : res.status(403).json({error:'Forbidden'});
}

app.get('/health',(req,res)=>res.json({ok:true, service:'absensi-backend-v1'}));

/* Demo login. Replace this route with Google OAuth verification in production. */
app.post('/auth/demo-login',(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase();
  const u=users.find(x=>x.email===email && x.active);
  if(!u) return res.status(401).json({error:'Akun belum terdaftar'});
  const token=jwt.sign({sub:u.id,email:u.email,name:u.name,role:u.role},JWT_SECRET,{expiresIn:'7d'});
  res.json({token,user:u});
});

app.get('/me',auth,(req,res)=>{
  const u=users.find(x=>x.id===req.user.sub);
  res.json({user:u});
});

app.get('/settings',auth,(req,res)=>res.json({
  checkInTime: CHECK_IN_TIME, checkOutTime: CHECK_OUT_TIME, timezone:'Asia/Jakarta'
}));

app.get('/holidays',auth,(req,res)=>res.json({holidays}));

app.post('/holidays',auth,requireRole('ADMIN'),(req,res)=>{
  const {date,name}=req.body;
  if(!/^\\d{4}-\\d{2}-\\d{2}$/.test(date)) return res.status(400).json({error:'Tanggal harus YYYY-MM-DD'});
  if(!holidays.includes(date)) holidays.push(date);
  res.json({date,name:name||'Libur'});
});

app.get('/attendance/today',auth,(req,res)=>{
  const date=dateKey();
  const rows=attendance.filter(a=>a.date===date);
  res.json({date,isHoliday:holidays.includes(date),rows});
});

app.get('/attendance/mine',auth,(req,res)=>{
  const employee=employees.find(e=>e.userId===req.user.sub);
  const rows=attendance.filter(a=>a.employeeId===employee?.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  res.json(rows);
});

app.post('/attendance/in',auth,(req,res)=>{
  const date=dateKey();
  if(holidays.includes(date)) return res.status(400).json({error:'Hari libur'});
  const employee=employees.find(e=>e.userId===req.user.sub);
  let row=attendance.find(a=>a.employeeId===employee.id && a.date===date);
  if(row?.checkIn) return res.status(400).json({error:'Absen IN sudah dilakukan',row});
  const now=jakartaNow();
  if(!row) {
    row={id:uuid(),employeeId:employee.id,date,checkIn:null,checkOut:null,checkInStatus:null,checkOutStatus:null,
      latitudeIn:null,longitudeIn:null,photoIn:null,createdAt:now.toISOString(),updatedAt:now.toISOString()};
    attendance.push(row);
  }
  row.checkIn=now.toISOString();
  row.checkInStatus=statusForIn(now);
  row.latitudeIn=req.body.latitude??null; row.longitudeIn=req.body.longitude??null; row.photoIn=req.body.photoUrl??null;
  row.updatedAt=now.toISOString();
  res.json(row);
});

app.post('/attendance/out',auth,(req,res)=>{
  const date=dateKey();
  if(holidays.includes(date)) return res.status(400).json({error:'Hari libur'});
  const employee=employees.find(e=>e.userId===req.user.sub);
  const row=attendance.find(a=>a.employeeId===employee.id && a.date===date);
  if(!row?.checkIn) return res.status(400).json({error:'Belum melakukan Absen IN'});
  if(row.checkOut) return res.status(400).json({error:'Absen OUT sudah dilakukan',row});
  const now=jakartaNow();
  row.checkOut=now.toISOString();
  row.checkOutStatus=(now.getHours()*60+now.getMinutes()) >= minutes(CHECK_OUT_TIME) ? 'ON_TIME' : 'EARLY';
  row.latitudeOut=req.body.latitude??null; row.longitudeOut=req.body.longitude??null; row.photoOut=req.body.photoUrl??null;
  row.updatedAt=now.toISOString();
  res.json(row);
});

app.get('/employees',auth,requireRole('ADMIN','OPERATOR'),(req,res)=>{
  res.json(users.map(u=>({...u, employee:employees.find(e=>e.userId===u.id)})));
});

app.patch('/employees/:id/role',auth,requireRole('ADMIN'),(req,res)=>{
  const u=users.find(x=>x.id===req.params.id);
  if(!u) return res.status(404).json({error:'User tidak ditemukan'});
  if(!roles.includes(req.body.role)) return res.status(400).json({error:'Role tidak valid'});
  u.role=req.body.role;
  res.json(u);
});

/* Placeholder for future realtime integration. Client can poll this endpoint in V1. */
app.get('/realtime/attendance',auth,requireRole('ADMIN','OPERATOR'),(req,res)=>{
  res.json({serverTime:new Date().toISOString(), rows:attendance});
});

app.listen(PORT,()=>console.log(`Absensi API running on http://localhost:${PORT}`));
