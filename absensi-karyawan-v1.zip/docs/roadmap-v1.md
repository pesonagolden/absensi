# Roadmap

1. V1 MVP: demo login, role, attendance, holiday, server timestamp.
2. V1.1: PostgreSQL repository.
3. V1.2: Google OAuth production.
4. V1.3: GPS + radius kantor + foto kamera.
5. V1.4: Nextcloud upload.
6. V1.5: Google Sheets synchronization.
7. V1.6: push notifications at 08:30 and 17:30.
8. V1.7: Indonesian holiday/calendar source and admin override.
9. V1.8: realtime WebSocket/SSE instead of polling.
10. V2: reports, payroll export, audit log, device/session management.
