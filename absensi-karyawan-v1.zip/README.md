# Absensi Karyawan V1

MVP aplikasi absensi dengan Expo + React Native dan backend Node.js/Express.

## Fitur V1
- Login demo berbasis email (Google OAuth disiapkan sebagai titik integrasi)
- Role: Admin, Operator, User
- Admin mengelola karyawan dan role
- Absen IN/OUT
- Jam kerja 08:30 / 17:30
- Timestamp server
- Status tepat waktu / terlambat
- Hari libur
- Riwayat absensi
- Endpoint realtime polling
- Struktur siap untuk PostgreSQL, Google Sheets, Nextcloud, GPS/foto, dan push notification

## Menjalankan backend
```bash
cd backend
npm install
npm run dev
```

Default: http://localhost:4000

## Menjalankan mobile
```bash
cd mobile
npm install
npx expo start
```

> Untuk HP fisik, ubah API_BASE_URL di `mobile/src/config.js` menjadi IP komputer di jaringan yang sama, misalnya `http://192.168.1.10:4000`.

## Akun demo
- admin@demo.local -> Admin
- operator@demo.local -> Operator
- user@demo.local -> User

V1 sengaja memakai login demo agar aplikasi dapat langsung diuji. Google OAuth production membutuhkan Client ID/redirect configuration milik project Google Anda.
