// Ganti dengan IP komputer Anda saat memakai HP fisik.
// Contoh: http://192.168.1.10:4000
export const API_BASE_URL = 'http://localhost:4000';
