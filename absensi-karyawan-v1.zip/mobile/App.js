import React, {useEffect, useState} from 'react';
import {SafeAreaView, View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator} from 'react-native';
import {StatusBar} from 'expo-status-bar';
import {API_BASE_URL} from './src/config';

const demoAccounts = [
  ['admin@demo.local','ADMIN'], ['operator@demo.local','OPERATOR'], ['user@demo.local','USER']
];

async function api(path, options={}, token) {
  const r=await fetch(API_BASE_URL+path,{
    ...options,
    headers:{'Content-Type':'application/json', ...(options.headers||{}), ...(token?{Authorization:`Bearer ${token}`}:{})}
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||'Request gagal');
  return data;
}

export default function App(){
  const [token,setToken]=useState(null);
  const [user,setUser]=useState(null);
  const [email,setEmail]=useState('admin@demo.local');
  const [loading,setLoading]=useState(false);
  const [today,setToday]=useState(null);
  const [history,setHistory]=useState([]);
  const [employees,setEmployees]=useState([]);

  async function login(){
    setLoading(true);
    try {
      const d=await api('/auth/demo-login',{method:'POST',body:JSON.stringify({email})});
      setToken(d.token); setUser(d.user);
    } catch(e){Alert.alert('Login gagal',e.message)} finally{setLoading(false)}
  }
  async function refresh(){
    if(!token) return;
    try {
      const [t,h]=await Promise.all([api('/attendance/today',{},token),api('/attendance/mine',{},token)]);
      setToday(t); setHistory(h);
      if(user?.role==='ADMIN'||user?.role==='OPERATOR') setEmployees(await api('/employees',{},token));
    } catch(e){Alert.alert('Error',e.message)}
  }
  useEffect(()=>{refresh()},[token]);
  useEffect(()=>{if(token){const id=setInterval(refresh,10000);return()=>clearInterval(id)}},[token,user]);

  async function punch(type){
    setLoading(true);
    try { await api(`/attendance/${type}`,{method:'POST',body:JSON.stringify({})},token); await refresh(); Alert.alert('Berhasil',`Absen ${type.toUpperCase()} tersimpan`); }
    catch(e){Alert.alert('Absensi',e.message)} finally{setLoading(false)}
  }
  async function changeRole(id,role){
    try { await api(`/employees/${id}/role`,{method:'PATCH',body:JSON.stringify({role})},token); await refresh(); }
    catch(e){Alert.alert('Role',e.message)}
  }

  if(!token) return <SafeAreaView style={s.container}><StatusBar style="auto"/>
    <View style={s.card}><Text style={s.title}>Absensi Karyawan</Text><Text style={s.sub}>V1 • Login demo</Text>
      <TextInput style={s.input} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email"/>
      <TouchableOpacity style={s.primary} onPress={login} disabled={loading}><Text style={s.btnText}>{loading?'Memproses…':'Masuk'}</Text></TouchableOpacity>
      <Text style={s.hint}>Demo:</Text>{demoAccounts.map(x=><Text key={x[0]} style={s.hint}>{x[0]} → {x[1]}</Text>)}
    </View>
  </SafeAreaView>;

  const row=today?.rows?.find(x=>x.employeeId); // for demo/user
  return <SafeAreaView style={s.container}><StatusBar style="auto"/><ScrollView contentContainerStyle={s.scroll}>
    <View style={s.header}><View><Text style={s.title}>Halo, {user?.name}</Text><Text style={s.sub}>{user?.email} • {user?.role}</Text></View>
    <TouchableOpacity onPress={()=>{setToken(null);setUser(null)}}><Text style={s.logout}>Keluar</Text></TouchableOpacity></View>
    <View style={s.card}><Text style={s.section}>Absensi Hari Ini</Text><Text>Jam IN: 08:30</Text><Text>Jam OUT: 17:30</Text>
      {today?.isHoliday?<Text style={s.holiday}>🔴 Hari libur</Text>:<View style={s.actions}>
        <TouchableOpacity style={s.primary} onPress={()=>punch('in')}><Text style={s.btnText}>ABSEN IN</Text></TouchableOpacity>
        <TouchableOpacity style={s.secondary} onPress={()=>punch('out')}><Text style={s.btnText}>ABSEN OUT</Text></TouchableOpacity>
      </View>}
      <Text style={s.small}>Data diperbarui otomatis setiap 10 detik.</Text>
    </View>
    <View style={s.card}><Text style={s.section}>Riwayat Saya</Text>{history.length===0?<Text>Belum ada data.</Text>:history.map(a=><View key={a.id} style={s.item}>
      <Text style={s.bold}>{a.date}</Text><Text>IN: {a.checkIn?new Date(a.checkIn).toLocaleTimeString():'—'} ({a.checkInStatus||'—'})</Text><Text>OUT: {a.checkOut?new Date(a.checkOut).toLocaleTimeString():'—'} ({a.checkOutStatus||'—'})</Text>
    </View>)}</View>
    {(user?.role==='ADMIN'||user?.role==='OPERATOR')&&<View style={s.card}><Text style={s.section}>Karyawan</Text>{employees.map(e=><View key={e.id} style={s.item}>
      <Text style={s.bold}>{e.name}</Text><Text>{e.email}</Text><Text>Role: {e.role}</Text>
      {user?.role==='ADMIN'&&<View style={s.roleRow}>{['USER','OPERATOR','ADMIN'].map(r=><TouchableOpacity key={r} onPress={()=>changeRole(e.id,r)} style={[s.roleBtn,e.role===r&&s.roleActive]}><Text>{r}</Text></TouchableOpacity>)}</View>}
    </View>)}</View>}
  </ScrollView></SafeAreaView>;
}

const s=StyleSheet.create({
 container:{flex:1,backgroundColor:'#f4f6f8'},scroll:{padding:16,paddingBottom:40},
 card:{backgroundColor:'#fff',borderRadius:16,padding:18,marginBottom:14,shadowOpacity:.08,shadowRadius:8,elevation:2},
 header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:14},
 title:{fontSize:24,fontWeight:'800'},sub:{color:'#667085',marginTop:4},section:{fontSize:18,fontWeight:'800',marginBottom:10},
 input:{borderWidth:1,borderColor:'#d0d5dd',borderRadius:10,padding:13,marginVertical:12},
 primary:{backgroundColor:'#111827',padding:14,borderRadius:10,alignItems:'center',marginTop:12},secondary:{backgroundColor:'#475467',padding:14,borderRadius:10,alignItems:'center',marginTop:10},
 btnText:{color:'#fff',fontWeight:'800'},actions:{marginTop:10},hint:{color:'#667085',marginTop:5},small:{fontSize:12,color:'#98a2b3',marginTop:12},
 holiday:{marginTop:14,fontWeight:'800'},item:{paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#eee'},bold:{fontWeight:'800'},logout:{fontWeight:'700'},
 roleRow:{flexDirection:'row',gap:6,marginTop:8},roleBtn:{borderWidth:1,borderColor:'#ddd',padding:7,borderRadius:8},roleActive:{backgroundColor:'#e5e7eb'}
});
